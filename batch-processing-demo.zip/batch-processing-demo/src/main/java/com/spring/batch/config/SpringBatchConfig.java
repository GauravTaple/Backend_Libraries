package com.spring.batch.config;

import com.spring.batch.entity.BicReminder;
import com.spring.batch.entity.RecordLog;
import com.spring.batch.repository.RecordLogRepository;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.extensions.excel.RowMapper;
import org.springframework.batch.extensions.excel.mapping.BeanWrapperRowMapper;
import org.springframework.batch.extensions.excel.poi.PoiItemReader;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.data.RepositoryItemWriter;
import org.springframework.batch.item.file.MultiResourceItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.transaction.PlatformTransactionManager;

import java.io.IOException;


@Configuration
public class SpringBatchConfig {

    @Autowired
    private RecordLogRepository repository;

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private PlatformTransactionManager transactionManager;

    private static final String filePath ="/home/jay/eStatements";


    @Bean
    public Job statementJob(JobRepository jobRepository) {
        return new JobBuilder("reminder-statement-job", jobRepository)
                .flow(generatedStatementStep())
                .next(generateOSPStep())
//                .next(deleteSourceStep)
                .end()
                .build();
    }

    @Bean
    public Step generatedStatementStep(){
        try {
            return new StepBuilder("generated-statement-Step", jobRepository)
                    .<BicReminder, RecordLog>chunk(10,transactionManager)
                    .reader(multiResourceItemReader())
                    .processor(itemProcessor())
                    .writer(itemWriter())
                    .build();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    //File delete tasklet
    @Bean
    public Step deleteSourceStep(PlatformTransactionManager txManager, JobRepository jobRepository) {

        DeleteSourceTasklet task = new DeleteSourceTasklet();
        ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();

        try {
            task.setResources(resolver.getResources("file:" + filePath+"/input/*.xlsx"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return new StepBuilder("delete-source-step", jobRepository)
                .tasklet(task, txManager)
                .build();
    }

//                .writer(reports -> {
//                    for (BicReminder report : reports) {
//                        System.out.println(report);
//                    }
//                })
//                .build();
//    }

    @Bean
    public Step generateOSPStep(){
        try {
            Workbook workbook = new XSSFWorkbook();
            return new StepBuilder("generate-osp-Step", jobRepository)
                    .<BicReminder, BicReminder>chunk(10,transactionManager)
                    .reader(multiResourceItemReader())
                    .processor(emailFilterProcessor())
                    .writer(excelItemWriter(workbook))
//                    .writer(reports -> {
//                        for (BicReminder report : reports) {
//                            System.out.println(report);
//                        }
//                    })
                    .build();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Bean
    public MultiResourceItemReader<BicReminder> multiResourceItemReader() throws IOException {
        MultiResourceItemReader<BicReminder> resourceItemReader = new MultiResourceItemReader<BicReminder>();
        ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();

        Resource[] resources = resolver.getResources("file:" + filePath+"/input/*.xlsx");
        resourceItemReader.setResources(resources);
        resourceItemReader.setDelegate(excelItemReader());
        return resourceItemReader;
    }

    @Bean
    public PoiItemReader<BicReminder> excelItemReader() {
        PoiItemReader<BicReminder> reader = new PoiItemReader<>();
        reader.setLinesToSkip(1);
        reader.setRowMapper(excelRowMapper());
        return reader;
    }

    private RowMapper<BicReminder> excelRowMapper() {
        BeanWrapperRowMapper<BicReminder> rowMapper = new BeanWrapperRowMapper<>();
        rowMapper.setTargetType(BicReminder.class);
        return rowMapper;
    }

    @Bean
    public ExcelItemWriter excelItemWriter(Workbook workbook) {
        return new ExcelItemWriter(filePath+"/osp/BIC_REMINDER_FILTER_EMAIL.xlsx",0, workbook);
    }

    @Bean
    public RepositoryItemWriter<RecordLog> itemWriter(){
        RepositoryItemWriter<RecordLog> itemWriter = new RepositoryItemWriter<>();
        itemWriter.setRepository(repository);
        itemWriter.setMethodName("save");
        return itemWriter;
    }


    public ItemProcessor<BicReminder, RecordLog> itemProcessor() {
        return new BicReminderItemProcessor();
    }

    public ItemProcessor<BicReminder, BicReminder> emailFilterProcessor(){
        return new EmailFilterItemProcessor();
    }



//    @Bean
//    public PoiItemReader<BicReminder> excelItemReader() {
//        PoiItemReader<BicReminder> reader = new PoiItemReader<>();
//        reader.setLinesToSkip(1); // Skip header row
//        try {
//            reader.setResource(new PathResource(filePath+"BIC_REMINDER_DATED.xlsx"));
//        } catch (Exception e) {
//            System.out.println("Error while reading file");
//            throw new RuntimeException(e);
//        }
//        reader.setRowMapper(excelRowMapper());
//        return reader;

//    }
}











