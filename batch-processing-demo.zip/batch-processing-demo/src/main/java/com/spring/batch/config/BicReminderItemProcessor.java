package com.spring.batch.config;

import com.itextpdf.html2pdf.HtmlConverter;
import com.spring.batch.entity.BicReminder;
import com.spring.batch.entity.RecordLog;
import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemProcessor;

import java.io.*;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

public class BicReminderItemProcessor implements ItemProcessor<BicReminder, RecordLog> {

    private static final String filePath ="/home/jay/eStatements/";

    private Long jobExecutionId;

    @BeforeStep
    public void beforeStep(StepExecution stepExecution) {
         jobExecutionId = stepExecution.getJobExecutionId();
        System.out.println("Job_Id ------ {} "+ jobExecutionId);
    }

    @Override
    public RecordLog process(BicReminder bicReminder) throws Exception {

        Map<String, String> templateParams = new HashMap<>();
        templateParams.put("type", bicReminder.getType());
        templateParams.put("name", bicReminder.getName());
        templateParams.put("poskod", bicReminder.getPoskod());
        templateParams.put("city", bicReminder.getCity());
        templateParams.put("date", bicReminder.getDate());
        templateParams.put("card_no", bicReminder.getCardBic());
        templateParams.put("ac_no", bicReminder.getAcNo());
        templateParams.put("amount", bicReminder.getAmount());


        String address = null;
        if(StringUtils.isNotEmpty(bicReminder.getAdd1())){
            address = bicReminder.getAdd1();
        }
        if (StringUtils.isNotBlank(bicReminder.getAdd2())) {
            address=address.concat("<br>" + bicReminder.getAdd2());
        }
        if (StringUtils.isNotBlank(bicReminder.getAdd3())) {
            address=address.concat("<br>" + bicReminder.getAdd3());
        }
        if (StringUtils.isNotBlank(bicReminder.getAdd4())) {
            address=address.concat("<br>" + bicReminder.getAdd4());
        }
        if (StringUtils.isNotBlank(bicReminder.getAdd5())) {
            address=address.concat("<br>" + bicReminder.getAdd5());
        }

        templateParams.put("address", address);
        String fileName = null;
        switch (bicReminder.getType()) {
            case "CL01" -> {

                fileName = mapTemplateParameters(filePath + "input/BicReminderCL01.html", templateParams, bicReminder);
                return RecordLog.builder()
                        .generatedFileName(fileName)
                        .email((bicReminder.getEmail() != null ? bicReminder.getEmail() : null))
                        .password(bicReminder.getNamePsw().strip().substring(0, 2) + bicReminder.getIcNo().strip().substring((bicReminder.getIcNo().strip().length() - 6)))
                        .generatedAt(LocalDateTime.now())
                        .sourceFileName(bicReminder.getResource().getFile().getName())
                        .jobExecutionId(jobExecutionId)
                        .build();
            }
            case "CL02" -> {
                fileName = mapTemplateParameters(filePath + "input/BicReminderCL02.html", templateParams, bicReminder);
                return RecordLog.builder()
                        .generatedFileName(fileName)
                        .email((bicReminder.getEmail() != null ? bicReminder.getEmail() : null))
                        .password(bicReminder.getNamePsw().strip().substring(0, 2) + bicReminder.getIcNo().strip().substring((bicReminder.getIcNo().strip().length() - 6)))
                        .generatedAt(LocalDateTime.now())
                        .sourceFileName(bicReminder.getResource().getFile().getName())
                        .jobExecutionId(jobExecutionId)
                        .build();
            }
            case "CL03" -> {
                fileName = mapTemplateParameters(filePath + "input/BicReminderCL03.html", templateParams, bicReminder);
                return RecordLog.builder()
                        .generatedFileName(fileName)
                        .email((bicReminder.getEmail() != null ? bicReminder.getEmail() : null))
                        .password(bicReminder.getNamePsw().strip().substring(0, 2) + bicReminder.getIcNo().strip().substring((bicReminder.getIcNo().strip().length() - 6)))
                        .generatedAt(LocalDateTime.now())
                        .sourceFileName(bicReminder.getResource().getFile().getName())
                        .jobExecutionId(jobExecutionId)
                        .build();
            }
        }
        return null;
    }

    private static String  mapTemplateParameters(String template, Map<String, String> templateParameters, BicReminder bicReminder){
        FileOutputStream fOut = null;

        String content = convertHtmlToString(template);
        String fileName = bicReminder.getType()+"BicReminder_"+bicReminder.getNamePsw().strip()+bicReminder.getIcNo().strip()+".pdf";

        try {
            for (Map.Entry<String, String> entry : templateParameters.entrySet()) {
                content = content.replace("${" + entry.getKey() + "}", entry.getValue());
            }


            File file = null;

            if (bicReminder.getType().equals("CL01")) {

                file = new File(filePath+"output/CL01", fileName);

            } else if(bicReminder.getType().equals("CL02")){

                file = new File(filePath+"output/CL02", fileName);
            }
            else if(bicReminder.getType().equals("CL03")){

                file = new File(filePath+"output/CL03", fileName);
            }

            fOut = new FileOutputStream(file);

            HtmlConverter.convertToPdf(content, fOut);
        }catch(Exception e) {

        } finally {
            if(fOut != null) {
                try {
                    fOut.close();
                } catch (IOException e) {
                }
            }
        }
        return fileName;
    }

    private static String   convertHtmlToString(String filePath) {
        StringBuilder builder = new StringBuilder();
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(filePath));
            String html;
            while ((html = bufferedReader.readLine()) != null) {
                builder.append(html);
            }
            bufferedReader.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return builder.toString();
    }

}
