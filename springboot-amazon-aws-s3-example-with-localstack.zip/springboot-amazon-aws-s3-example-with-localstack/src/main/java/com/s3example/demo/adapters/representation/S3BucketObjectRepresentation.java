package com.s3example.demo.adapters.representation;

import lombok.Data;

@Data
public class S3BucketObjectRepresentation {

    private String objectName;
    private String text;
}
