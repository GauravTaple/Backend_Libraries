package com.freeMarker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FreeMarkerApplicationTests {

	@Test
	void contextLoads() {
	}

}
