package co.reldyn.datafile.casa;

import com.fasterxml.jackson.databind.ObjectMapper;
import name.velikodniy.vitaliy.fixedlength.FixedLength;

import java.io.*;
import java.util.List;

public class DemoRun {
        public static void main(String[] args) throws IOException {
                InputStream is = new FileInputStream("cdb322w.txt");
                List<CasaRecord> allRecords = new FixedLength<CasaRecord>()
                                .registerLineType(CasaRecord.class)
                                .parse(is);
                System.out.println(allRecords + "allRecords");

                ObjectMapper objectMapper = new ObjectMapper();
                List<CasaRecord> records = allRecords.stream().limit(5).toList();
                String json = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(records);
                
                System.out.println(json);
                
        }
}
		