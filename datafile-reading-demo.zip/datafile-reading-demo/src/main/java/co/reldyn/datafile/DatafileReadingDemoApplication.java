package co.reldyn.datafile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatafileReadingDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatafileReadingDemoApplication.class, args);
	}

}
