package co.reldyn.datafile.casa;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import name.velikodniy.vitaliy.fixedlength.annotation.FixedField;

@Data
@Builder
@AllArgsConstructor																									
@NoArgsConstructor
public class CasaRecord {

    @FixedField(length = 19, offset = 1)
    private String accountNumber;

    @FixedField(length = 6, offset = 19)
    private String runningSequenceNumber;

    @FixedField(length = 14, offset = 25)
    private String txnDateTime;

    @FixedField(length = 14, offset = 39)
    private String authorisedCurrentAC;

    @FixedField(length = 4, offset = 53)
    private String txnCode;
    
    @FixedField(length = 20, offset = 57)
    private String txnDescription;
    
    @FixedField(length = 11, offset = 77)
    private String referenceNumber;
    
    @FixedField(length = 1, offset = 88)
    private String txnSign;
    
    @FixedField(length = 15, offset = 89)
    private String txnAmount;
    
    @FixedField(length = 3, offset = 104)
    private String txnServicingBranch;
    
    @FixedField(length = 18, offset = 107)
    private String eftNumber;
    
    @FixedField(length = 1, offset = 125)
    private String statementEndingBalSign;
 
    @FixedField(length = 15, offset = 126)
    private String statementEndingBalance;
 
    @FixedField(length = 40, offset = 141)
    private String paymentDetail;
 
    @FixedField(length = 4, offset = 181)
    private String accountCurrency;
 
    @FixedField(length = 4, offset = 185)
    private String mappedSwiftCode;
 
    @FixedField(length = 7, offset = 189)
    private String julianDate;
 
    @FixedField(length = 3, offset = 196)
    private String sourceBranch;
 
    @FixedField(length = 15, offset = 199)
    private String reservedAmount1;
 
    @FixedField(length = 15, offset = 214)
    private String reservedAmount2;
 
    @FixedField(length = 15, offset = 229)
    private String reservedAmount3;
 
    @FixedField(length = 15, offset = 244)
    private String reservedAmount4;
 
    @FixedField(length = 15, offset = 259)
    private String reservedAmount5;
 
    @FixedField(length = 10, offset = 274)
    private String remarks1;
 
    @FixedField(length = 10, offset = 284)
    private String remarks2;
 
    @FixedField(length = 10, offset = 294)
    private String remarks3;
 
    @FixedField(length = 10, offset = 304)
    private String remarks4;
 
    @FixedField(length = 10, offset = 314)
    private String remarks5;
 
    @FixedField(length = 3, offset = 324)
    private String accountBranch;
 
    @FixedField(length = 1, offset = 327)
    private String accountStatus;
 
    @FixedField(length = 19, offset = 328)
    private String cifNumber;
 
    @FixedField(length = 1, offset = 347)
    private String classCode;
 
    @FixedField(length = 3, offset = 348)
    private String lob;
 
    @FixedField(length = 2, offset = 351)
    private String sectorCode;
 
    @FixedField(length = 2, offset = 353)
    private String productCode;
 
    @FixedField(length = 225, offset = 355)
    private String filler1;
 
    @FixedField(length = 256, offset = 580)
    private String filler2;
 
    @FixedField(length = 40, offset = 836)
    private String filler3;
    
    @FixedField(length = 40, offset = 876)
    private String filler4;
}
